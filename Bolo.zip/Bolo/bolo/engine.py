"""Speech-to-text engine: faster-whisper running on this computer.

First start downloads the model once (needs internet). After that Bolo works
fully offline. No account, no subscription, no limit on how much you dictate.
"""
import threading

import numpy as np

from . import translit

# Priming text. Whisper imitates the style of the prompt, so a Hinglish prompt
# makes it write Hindi in English letters, and a Devanagari-with-English prompt
# keeps English words in English while Hindi stays in Devanagari.
PROMPT_HINGLISH = ("Kal ki meeting 11 baje hai, please send me the updated report. "
                   "Theek hai, main aaj hi share kar deta hoon.")
PROMPT_DEVANAGARI = ("कल की meeting 11 बजे है, please send me the updated report. "
                     "ठीक है, मैं आज ही share कर देता हूँ।")
PROMPT_ENGLISH = "Hello, this is a clear sentence with proper punctuation."

_HALLUCINATIONS = {
    "thank you", "thanks for watching", "thank you for watching", "you", "bye",
    "subtitles by the amara.org community", "धन्यवाद", "thank you very much",
}


class Engine:
    def __init__(self, cfg, on_status=None):
        self.cfg = cfg
        self.on_status = on_status or (lambda msg: None)
        self._model = None
        self._loaded = None            # (model_name, device)
        self._lock = threading.Lock()  # one transcription at a time
        self._force_cpu = False

    # -- loading ---------------------------------------------------------
    @staticmethod
    def _cuda_available() -> bool:
        try:
            import ctranslate2
            return ctranslate2.get_cuda_device_count() > 0
        except Exception:
            return False

    def _load(self):
        from faster_whisper import WhisperModel
        name = self.cfg.model_name
        use_gpu = self._cuda_available() and not self._force_cpu
        want = (name, "cuda" if use_gpu else "cpu")
        if self._model is not None and self._loaded == want:
            return
        self.on_status(f"Loading the '{name}' model… (the first time it downloads once)")
        if use_gpu:
            try:
                self._model = WhisperModel(name, device="cuda", compute_type="float16")
                self._loaded = want
                self.on_status("")
                return
            except Exception:
                self._force_cpu = True
                want = (name, "cpu")
        self._model = WhisperModel(name, device="cpu", compute_type="int8",
                                   cpu_threads=0)
        self._loaded = want
        self.on_status("")

    def preload(self):
        with self._lock:
            self._load()

    # -- transcription ---------------------------------------------------
    def _language_and_prompt(self):
        mode = self.cfg["language_mode"]
        script = self.cfg["hindi_script"]
        if mode == "en":
            lang, prompt = "en", PROMPT_ENGLISH
        else:  # "hi" or "mix": mixed speech is decoded as Hindi + English words
            lang = "hi"
            prompt = PROMPT_HINGLISH if script == "hinglish" else PROMPT_DEVANAGARI
        names = [p[1] for p in self.cfg["dictionary"] if len(p) == 2 and p[1].strip()]
        if names:
            prompt = prompt + " " + ", ".join(names[:30]) + "."
        return lang, prompt

    def transcribe(self, audio: np.ndarray) -> str:
        """audio: 16 kHz mono float32. Returns the raw text (may be empty)."""
        if audio.size < 16000 * 0.3:
            return ""
        rms = float(np.sqrt(np.mean(audio * audio)))
        if rms < 0.002:
            return ""
        lang, prompt = self._language_and_prompt()
        with self._lock:
            self._load()
            try:
                text = self._run(audio, lang, prompt)
            except RuntimeError as e:
                # Typical on PCs without the CUDA libraries: retry on the CPU.
                if self._loaded and self._loaded[1] == "cuda" and any(
                        k in str(e).lower() for k in ("cublas", "cudnn", "cuda")):
                    self._force_cpu = True
                    self._model = None
                    self._load()
                    text = self._run(audio, lang, prompt)
                else:
                    raise
        text = text.strip()
        if text.lower().strip(" .!,") in _HALLUCINATIONS and audio.size < 16000 * 3:
            return ""
        if self.cfg["hindi_script"] == "hinglish" and lang == "hi":
            text = translit.to_roman(text)
        return text

    def _run(self, audio, lang, prompt) -> str:
        segments, _info = self._model.transcribe(
            audio,
            language=lang,
            task="transcribe",
            initial_prompt=prompt,
            beam_size=5,
            vad_filter=True,
            vad_parameters={"min_silence_duration_ms": 500},
            condition_on_previous_text=False,
            no_speech_threshold=0.6,
        )
        return " ".join(s.text.strip() for s in segments)
