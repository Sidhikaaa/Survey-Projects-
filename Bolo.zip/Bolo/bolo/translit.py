"""Devanagari -> Roman ("Hinglish") fallback.

Whisper normally writes Hinglish in English letters when it is primed with a
Hinglish prompt (see engine.py). This is only a safety net for when a Hindi
word still comes out in Devanagari: it converts it to the way people type
Hindi on a phone keyboard. It is rule based and approximate, not perfect.
"""
import re
import unicodedata

CONS = {
    "क": "k", "ख": "kh", "ग": "g", "घ": "gh", "ङ": "n",
    "च": "ch", "छ": "chh", "ज": "j", "झ": "jh", "ञ": "n",
    "ट": "t", "ठ": "th", "ड": "d", "ढ": "dh", "ण": "n",
    "त": "t", "थ": "th", "द": "d", "ध": "dh", "न": "n",
    "प": "p", "फ": "ph", "ब": "b", "भ": "bh", "म": "m",
    "य": "y", "र": "r", "ल": "l", "व": "v", "श": "sh",
    "ष": "sh", "स": "s", "ह": "h", "ळ": "l",
}
NUKTA = {"क": "q", "ख": "kh", "ग": "g", "ज": "z", "ड": "r", "ढ": "rh", "फ": "f"}
VOWELS = {
    "अ": "a", "आ": "aa", "इ": "i", "ई": "ee", "उ": "u", "ऊ": "oo", "ऋ": "ri",
    "ए": "e", "ऐ": "ai", "ओ": "o", "औ": "au", "ऑ": "o", "ऍ": "e",
}
MATRAS = {
    "ा": "aa", "ि": "i", "ी": "ee", "ु": "u", "ू": "oo", "ृ": "ri",
    "े": "e", "ै": "ai", "ो": "o", "ौ": "au", "ॉ": "o", "ॅ": "e",
}
DIGITS = {c: str(i) for i, c in enumerate("०१२३४५६७८९")}

COMMON = {
    "है": "hai", "हैं": "hain", "में": "mein", "मैं": "main", "नहीं": "nahi",
    "और": "aur", "कि": "ki", "की": "ki", "के": "ke", "का": "ka", "को": "ko",
    "से": "se", "पर": "par", "यह": "yeh", "ये": "ye", "वह": "woh", "वो": "wo",
    "हूँ": "hoon", "हूं": "hoon", "हो": "ho", "था": "tha", "थी": "thi", "थे": "the",
    "तो": "to", "भी": "bhi", "ही": "hi", "क्या": "kya", "कुछ": "kuch",
    "आप": "aap", "हम": "hum", "तुम": "tum", "आज": "aaj", "कल": "kal",
    "अब": "ab", "जब": "jab", "तब": "tab", "कब": "kab", "कैसे": "kaise",
    "क्यों": "kyon", "ठीक": "theek", "बहुत": "bahut", "लिए": "liye",
    "साथ": "saath", "बाद": "baad", "पहले": "pehle", "पहला": "pehla",
    "कर": "kar", "करना": "karna", "करो": "karo", "दो": "do", "हाँ": "haan",
    "हां": "haan", "जी": "ji", "मेरा": "mera", "मेरी": "meri", "आपका": "aapka",
    "दूँगा": "doonga", "दूंगा": "doonga", "दूँगी": "doongi", "दूंगी": "doongi",
    "रहा": "raha", "रही": "rahi", "रहे": "rahe", "सकता": "sakta", "सकती": "sakti",
}

_DEV_RUN = re.compile(r"[ऀ-ॣ०-ॿ]+")


def has_devanagari(text: str) -> bool:
    return bool(re.search(r"[ऀ-ॿ]", text))


def _word(w: str) -> str:
    if w in COMMON:
        return COMMON[w]
    units = []  # [consonant_roman, vowel_roman ('' = none), kind, suffix]
    i, n = 0, len(w)
    while i < n:
        ch = w[i]
        if ch in CONS:
            c = CONS[ch]
            i += 1
            if i < n and w[i] == "़":
                c = NUKTA.get(ch, c)
                i += 1
            v = "a"
            if i < n and w[i] in MATRAS:
                v = MATRAS[w[i]]
                i += 1
            elif i < n and w[i] == "्":
                v = ""
                i += 1
            units.append([c, v, "c", ""])
        elif ch in VOWELS:
            units.append(["", VOWELS[ch], "v", ""])
            i += 1
        elif ch in "ँं":  # chandrabindu / anusvara
            if units:
                units[-1][3] += "n"
            else:
                units.append(["n", "", "r", ""])
            i += 1
        elif ch == "ः":  # visarga
            if units:
                units[-1][3] += "h"
            i += 1
        elif ch in DIGITS:
            units.append([DIGITS[ch], "", "r", ""])
            i += 1
        else:
            i += 1  # stray combining mark: skip
    count = len(units)
    if count == 0:
        return ""
    # Schwa deletion: final "a" first, then medial from right to left.
    if count > 1 and units[-1][2] == "c" and units[-1][1] == "a" and not units[-1][3]:
        units[-1][1] = ""
    for k in range(count - 2, 0, -1):
        u, prev, nxt = units[k], units[k - 1], units[k + 1]
        if u[2] == "c" and u[1] == "a" and not u[3] and prev[1] != "" and nxt[1] != "":
            u[1] = ""
    # Word-final long vowels read short in everyday Hinglish: kitna, tha, ki
    last = units[-1]
    if last[2] == "c":
        if last[1] == "aa":
            last[1] = "a"
        elif last[1] == "ee":
            last[1] = "i"
    return "".join(u[0] + u[1] + u[3] for u in units)


def to_roman(text: str) -> str:
    """Convert any Devanagari in `text` to Roman letters; other text is untouched."""
    text = unicodedata.normalize("NFC", text)
    text = text.replace("।", ".").replace("॥", ".")
    return _DEV_RUN.sub(lambda m: _word(m.group(0)), text)
