"""Settings storage for Bolo (a small JSON file in %APPDATA%\\Bolo)."""
import json
import os
import sys
import threading
from pathlib import Path


def data_dir() -> Path:
    base = os.environ.get("APPDATA") or str(Path.home() / ".config")
    p = Path(base) / "Bolo"
    p.mkdir(parents=True, exist_ok=True)
    return p


def meetings_dir() -> Path:
    p = Path.home() / "Documents" / "Bolo" / "Meetings"
    p.mkdir(parents=True, exist_ok=True)
    return p


# Accuracy level -> faster-whisper model name (downloaded once, then fully offline)
MODELS = {
    "fast": "small",
    "balanced": "large-v3-turbo",
    "best": "large-v3",
}

DEFAULTS = {
    "language_mode": "mix",          # en | hi | mix
    "hindi_script": "hinglish",      # hinglish | devanagari
    "accuracy": "balanced",          # fast | balanced | best
    "remove_fillers": True,
    "capitalize": True,
    "follow_corrections": True,
    "press_enter": False,
    "trailing_space": True,
    "hotkey_hold": "ctrl+windows",
    "hotkey_toggle": "ctrl+alt+space",
    "hotkey_meeting": "ctrl+alt+m",
    "start_with_windows": False,
    "show_bar": True,
    "mic_device": None,              # None = Windows default microphone
    "dictionary": [],                # list of [heard, written]
}


class Config:
    def __init__(self, path: Path | None = None):
        self.path = path or (data_dir() / "config.json")
        self._lock = threading.Lock()
        self.data = dict(DEFAULTS)
        self.load()

    def load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                saved = json.load(f)
            if isinstance(saved, dict):
                self.data.update({k: v for k, v in saved.items() if k in DEFAULTS})
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            pass

    def save(self):
        with self._lock:
            tmp = self.path.with_suffix(".tmp")
            try:
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(self.data, f, ensure_ascii=False, indent=2)
                os.replace(tmp, self.path)
            except OSError:
                pass

    def __getitem__(self, key):
        return self.data.get(key, DEFAULTS.get(key))

    def get(self, key, default=None):
        return self.data.get(key, default)

    def set(self, key, value):
        self.data[key] = value
        self.save()

    @property
    def model_name(self) -> str:
        return MODELS.get(self["accuracy"], MODELS["balanced"])


def set_autostart(enabled: bool, script_path: str):
    """Start Bolo with Windows (current user only, no admin needed)."""
    if sys.platform != "win32":
        return
    import winreg
    key = winreg.OpenKey(
        winreg.HKEY_CURRENT_USER,
        r"Software\Microsoft\Windows\CurrentVersion\Run",
        0,
        winreg.KEY_SET_VALUE,
    )
    try:
        if enabled:
            exe = sys.executable
            if exe.lower().endswith("python.exe"):
                exe = exe[:-10] + "pythonw.exe"
            winreg.SetValueEx(key, "Bolo", 0, winreg.REG_SZ, f'"{exe}" "{script_path}"')
        else:
            try:
                winreg.DeleteValue(key, "Bolo")
            except FileNotFoundError:
                pass
    finally:
        winreg.CloseKey(key)
