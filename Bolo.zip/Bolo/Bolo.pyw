import sys

from bolo.app import run

if __name__ == "__main__":
    sys.exit(run())
