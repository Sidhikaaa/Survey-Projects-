"""Turns raw speech-to-text into text you would actually send.

Everything here is plain rules - no cloud, no subscription.
"""
import re

_WEEKDAYS = "monday|tuesday|wednesday|thursday|friday|saturday|sunday"
_MONTHS = ("january|february|march|april|may|june|july|august|september|"
           "october|november|december")
_NUM = r"\d+(?:[.:]\d+)?"
_VAL = rf"(?:{_WEEKDAYS}|{_MONTHS}|{_NUM})"

_FILLER = re.compile(
    r"(?<![\w])(?:u+m+|u+h+m*|e+r+m+|h+m+|m{3,})(?![\w])[,.…]*\s*", re.I)

# "Tuesday, no, Wednesday" / "20 I mean 30"  ->  keep the corrected value
_VALUE_FIX = re.compile(
    rf"\b({_VAL})\b\s*[,.]?\s*"
    rf"(?:no|nope|nahi|nahin|sorry|actually|wait|I mean|no wait|no I mean|sorry I mean)"
    rf"(?:\s*[,.]?\s*(?:I mean|sorry|actually|wait))?\s*[,.]?\s*"
    rf"\b({_VAL})\b", re.I)

_SCRATCH = re.compile(r"[\s,.]*\b(?:scratch that|delete that|ignore that|cancel that)\b[\s,.]*", re.I)
_NEW_PARA = re.compile(r"(?:^|(?<=[.?!,]))\s*new paragraph\s*(?:[.?!,]|$)", re.I)
_NEW_LINE = re.compile(r"(?:^|(?<=[.?!,]))\s*new line\s*(?:[.?!,]|$)", re.I)
_SENT_END = re.compile(r"[.?!।]\s+")


def _scratch_that(text: str) -> str:
    """'A b c. D e f, scratch that. G' -> 'A b c. G' (drops the previous sentence)."""
    while True:
        m = _SCRATCH.search(text)
        if not m:
            return text
        before, after = text[:m.start()], text[m.end():]
        cut = 0
        for s in _SENT_END.finditer(before):
            cut = s.end()
        text = (before[:cut] + after).strip()


def _capitalize(text: str) -> str:
    def up_first(s: str) -> str:
        for idx, ch in enumerate(s):
            if ch.isalpha():
                return s[:idx] + ch.upper() + s[idx + 1:]
            if ch.isdigit():
                return s
        return s

    parts = re.split(r"([.?!]\s+|\n+)", text)
    out = []
    for i, p in enumerate(parts):
        out.append(up_first(p) if i % 2 == 0 else p)
    text = "".join(out)
    return re.sub(r"\bi\b(?=[\s'.,!?]|$)", "I", text)


def apply_dictionary(text: str, pairs) -> str:
    for pair in pairs or []:
        if not pair or len(pair) != 2 or not pair[0].strip():
            continue
        heard, written = pair[0].strip(), pair[1]
        text = re.sub(rf"(?<!\w){re.escape(heard)}(?!\w)", lambda _m, w=written: w,
                      text, flags=re.I)
    return text


def clean(text: str, cfg, voice_commands: bool = True) -> str:
    """cfg is anything with cfg[key] (bolo.config.Config or a dict)."""
    if not text:
        return ""
    t = text.strip()

    if cfg["follow_corrections"]:
        t = _scratch_that(t)
        t = _VALUE_FIX.sub(lambda m: m.group(2), t)

    if cfg["remove_fillers"]:
        t = _FILLER.sub("", t)

    if voice_commands:
        t = _NEW_PARA.sub("\n\n", t)
        t = _NEW_LINE.sub("\n", t)

    t = apply_dictionary(t, cfg["dictionary"])

    # tidy spacing and punctuation left behind by removals
    t = re.sub(r"[ \t]+", " ", t)
    t = re.sub(r"\s+([,.?!।;:])", r"\1", t)
    t = re.sub(r"([,.;:])\1+", r"\1", t)
    t = re.sub(r"^[\s,.;:]+", "", t)
    t = re.sub(r" ?\n ?", "\n", t).strip()

    if cfg["capitalize"]:
        t = _capitalize(t)
    return t
