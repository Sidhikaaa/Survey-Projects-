$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$desktop = [Environment]::GetFolderPath('Desktop')
$s = (New-Object -ComObject WScript.Shell).CreateShortcut("$desktop\Bolo.lnk")
$s.TargetPath = "$here\venv\Scripts\pythonw.exe"
$s.Arguments = "`"$here\Bolo.pyw`""
$s.WorkingDirectory = $here
$s.Description = "Bolo - speak, it types (English + Hindi)"
$s.Save()
