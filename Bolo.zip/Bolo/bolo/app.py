"""Bolo - speak in English and Hindi, it types. Free, offline, no subscription."""
import sys
import tempfile
from pathlib import Path

from PySide6.QtCore import QLockFile
from PySide6.QtWidgets import QApplication, QMessageBox

from .config import Config
from .core import Core
from .ui import QSS, FloatingBar, MainWindow, build_tray, make_icon


def run() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("Bolo")
    app.setQuitOnLastWindowClosed(False)
    app.setWindowIcon(make_icon("app"))
    app.setStyleSheet(QSS)

    lock = QLockFile(str(Path(tempfile.gettempdir()) / "bolo.lock"))
    lock.setStaleLockTime(0)
    if not lock.tryLock(200):
        QMessageBox.information(None, "Bolo", "Bolo is already running.\n"
                                "Look for its icon near the clock (system tray).")
        return 0

    cfg = Config()
    core = Core(cfg)
    win = MainWindow(core)
    bar = FloatingBar(core, win.show_normal)
    win.settings.bar = bar
    tray, quit_act = build_tray(app, core, win)

    def quit_app():
        try:
            if core.meeting_running:
                core.meeting.stop()
        finally:
            tray.hide()
            app.quit()
    quit_act.triggered.connect(quit_app)

    core.start()
    win.show()
    if cfg["show_bar"]:
        bar.show()
    code = app.exec()
    lock.unlock()
    return code
