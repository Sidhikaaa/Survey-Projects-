"""Plain tests (no pytest needed):  python tests/run_tests.py"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from bolo import cleanup, translit  # noqa: E402
from bolo.config import DEFAULTS  # noqa: E402
from bolo.segmenter import SR, Segmenter  # noqa: E402

CFG = dict(DEFAULTS)
passed = failed = 0


def check(name, got, want):
    global passed, failed
    if got == want:
        passed += 1
    else:
        failed += 1
        print(f"FAIL {name}\n   got : {got!r}\n   want: {want!r}")


def c(text, **over):
    cfg = dict(CFG)
    cfg.update(over)
    return cleanup.clean(text, cfg)


# ---- cleanup -------------------------------------------------------------
check("fillers", c("um so uh we should, umm, start tomorrow"), "So we should, start tomorrow")
check("hmm", c("Hmm. I think that works"), "I think that works")
check("units kept", c("the pipe is 5 mm thick"), "The pipe is 5 mm thick")
check("weekday fix", c("Let's meet Tuesday, no, Wednesday at 5"), "Let's meet Wednesday at 5")
check("number fix", c("send 20, I mean 30 copies"), "Send 30 copies")
check("scratch", c("Please call him. Send it today, scratch that. Send it tomorrow."),
      "Please call him. Send it tomorrow.")
check("new line", c("Dear Sam. New line. Thanks"), "Dear Sam.\nThanks")
check("a new line of products untouched", c("we launch a new line of products"),
      "We launch a new line of products")
check("capital I", c("i think i can do it. then i will go"), "I think I can do it. Then I will go")
check("dictionary", c("ken research is in gurugram",
                      dictionary=[["ken research", "Ken Research"]]),
      "Ken Research is in gurugram")
check("hinglish cap", c("kal meeting hai, please send the report"),
      "Kal meeting hai, please send the report")
check("devanagari untouched", c("आज शाम तक proposal share कर दूँगा।"),
      "आज शाम तक proposal share कर दूँगा।")
check("no fillers off", c("um hello", remove_fillers=False), "Um hello")
check("empty", c(""), "")

# ---- transliteration -------------------------------------------------------
T = translit.to_roman
check("t kal", T("कल"), "kal")
check("t hai", T("है"), "hai")
check("t sentence", T("कल की meeting है, please send the report"),
      "kal ki meeting hai, please send the report")
check("t samajh", T("समझ"), "samajh")
check("t samajhna", T("समझना"), "samajhna")
check("t kamal", T("कमल"), "kamal")
check("t bahut", T("बहुत"), "bahut")
check("t theek", T("ठीक"), "theek")
check("t danda", T("ठीक है।"), "theek hai.")
check("t shaam", T("शाम"), "shaam")
check("t latin untouched", T("hello world 123"), "hello world 123")
check("t nasal", T("यहाँ"), "yahan")
check("t sample", T("आज शाम तक proposal का पहला draft share कर दूँगा।"),
      "aaj shaam tak proposal ka pehla draft share kar doonga.")
check("t digit", T("१२३"), "123")

# ---- segmenter -------------------------------------------------------------
got = []
seg = Segmenter(lambda a, t: got.append((a.size / SR, t)), silence_s=0.9)
rng = np.random.default_rng(0)
t = 1000.0
for _ in range(10):            # 0.5 s of quiet noise
    seg.feed((rng.standard_normal(800) * 0.001).astype(np.float32), t)
    t += 0.05
for _ in range(40):            # 2 s of "speech"
    seg.feed((rng.standard_normal(800) * 0.1).astype(np.float32), t)
    t += 0.05
for _ in range(30):            # 1.5 s of silence -> flush after 0.9 s
    seg.feed((rng.standard_normal(800) * 0.001).astype(np.float32), t)
    t += 0.05
check("segmenter emits one utterance", len(got), 1)
check("segmenter length 2.0-3.5 s", 2.0 <= got[0][0] <= 3.5, True)

got.clear()                    # clock-based flush when no audio arrives (loopback)
seg = Segmenter(lambda a, t: got.append(a.size), silence_s=0.9)
t = 50.0
for _ in range(20):
    seg.feed((rng.standard_normal(800) * 0.1).astype(np.float32), t)
    t += 0.05
seg.tick(t + 0.5)
check("no flush before pause", len(got), 0)
seg.tick(t + 1.2)
check("tick flushes after pause", len(got), 1)

got.clear()                    # a short click is ignored
seg = Segmenter(lambda a, t: got.append(a.size))
seg.feed((rng.standard_normal(800) * 0.2).astype(np.float32), 10.0)
seg.tick(12.0)
check("short blip ignored", len(got), 0)

print(f"\n{passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
