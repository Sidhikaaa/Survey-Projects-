"""Types text into whatever app has the cursor (works for Hindi too).

It puts the text on the clipboard and presses Ctrl+V - the only method that
reliably handles Devanagari and emoji in every Windows app - then restores
whatever was on your clipboard before.
"""
import ctypes
import sys

from PySide6.QtCore import QMimeData, QTimer
from PySide6.QtGui import QGuiApplication


def foreground_title() -> str:
    if sys.platform != "win32":
        return ""
    try:
        u = ctypes.windll.user32
        hwnd = u.GetForegroundWindow()
        n = u.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer(n + 1)
        u.GetWindowTextW(hwnd, buf, n + 1)
        title = buf.value
        # "Inbox - Outlook" -> "Outlook"
        for sep in (" - ", " — ", " | "):
            if sep in title:
                title = title.split(sep)[-1]
                break
        return title[:40]
    except Exception:
        return ""


def type_text(text: str, press_enter: bool = False):
    import keyboard
    cb = QGuiApplication.clipboard()
    saved = QMimeData()
    try:
        src = cb.mimeData()
        for fmt in src.formats():
            saved.setData(fmt, src.data(fmt))
    except Exception:
        saved = None
    cb.setText(text)

    def paste():
        keyboard.send("ctrl+v")
        if press_enter:
            QTimer.singleShot(120, lambda: keyboard.send("enter"))

        def restore():
            if saved is not None:
                try:
                    cb.setMimeData(saved)
                except Exception:
                    pass
        QTimer.singleShot(700, restore)

    QTimer.singleShot(60, paste)
