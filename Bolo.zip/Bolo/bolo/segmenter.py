"""Cuts a continuous audio stream into spoken utterances (used for meetings)."""
import threading
import time
from collections import deque

import numpy as np

SR = 16000


class Segmenter:
    """Feed 16 kHz mono float32 audio. Calls on_utterance(audio, start_wall_time)
    after a pause in speech, or when an utterance gets too long.

    Call tick() a few times per second: some sources (WASAPI loopback) send no
    audio at all while nothing is playing, so silence has to be judged by the
    clock and not only by arriving audio.
    """

    def __init__(self, on_utterance, silence_s=0.9, max_s=25.0, min_s=0.5,
                 base_threshold=0.008, preroll_s=0.3):
        self.on_utterance = on_utterance
        self.silence_s = silence_s
        self.max_s = max_s
        self.min_s = min_s
        self.base_threshold = base_threshold
        self.preroll = deque()
        self.preroll_s = preroll_s
        self._preroll_len = 0
        self.noise = base_threshold / 3
        self.buf = []
        self.buf_len = 0
        self.voiced_len = 0
        self.active = False
        self.start_wall = 0.0
        self.last_voice = 0.0
        self.lock = threading.Lock()

    def feed(self, x: np.ndarray, now: float | None = None):
        if x.size == 0:
            return
        now = time.time() if now is None else now
        rms = float(np.sqrt(np.mean(x * x)))
        with self.lock:
            thr = max(self.base_threshold, self.noise * 3.0)
            voiced = rms > thr
            if not voiced:
                self.noise = 0.95 * self.noise + 0.05 * rms
            if voiced and not self.active:
                self.active = True
                self.start_wall = now - self.buf_len / SR - self._preroll_len / SR
                self.buf = list(self.preroll)
                self.buf_len = self._preroll_len
                self.voiced_len = 0
                self.preroll.clear()
                self._preroll_len = 0
            if self.active:
                self.buf.append(x)
                self.buf_len += x.size
                if voiced:
                    self.voiced_len += x.size
                    self.last_voice = now
                if self.buf_len / SR >= self.max_s:
                    self._flush_locked()
            else:
                self.preroll.append(x)
                self._preroll_len += x.size
                while self._preroll_len / SR > self.preroll_s and len(self.preroll) > 1:
                    self._preroll_len -= self.preroll.popleft().size
        self.tick(now)

    def tick(self, now: float | None = None):
        now = time.time() if now is None else now
        with self.lock:
            if self.active and now - self.last_voice >= self.silence_s:
                self._flush_locked()

    def flush(self):
        with self.lock:
            if self.active:
                self._flush_locked()

    def _flush_locked(self):
        audio = np.concatenate(self.buf) if self.buf else np.zeros(0, np.float32)
        voiced_s = self.voiced_len / SR
        start = self.start_wall
        self.buf, self.buf_len, self.voiced_len, self.active = [], 0, 0, False
        if voiced_s >= self.min_s and audio.size:
            try:
                self.on_utterance(audio, start)
            except Exception:
                pass
