@echo off
setlocal
cd /d "%~dp0"
echo.
echo  Bolo - one-time setup (needs internet; takes a few minutes)
echo.

set PY=
for %%V in (3.12 3.11 3.10) do (
  if not defined PY ( py -%%V -c "import sys" >nul 2>nul && set PY=py -%%V )
)
if not defined PY (
  echo  Python 3.10, 3.11 or 3.12 was not found.
  echo  Install Python 3.12 from https://www.python.org/downloads/
  echo  and tick "Add python.exe to PATH" in the installer, then run this file again.
  pause
  exit /b 1
)

if not exist venv ( %PY% -m venv venv )
call venv\Scripts\python.exe -m pip install --upgrade pip
call venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo  Something failed while installing. Please send a screenshot of this window.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0create_shortcut.ps1"
echo.
echo  Done. A "Bolo" shortcut is now on your Desktop. Double-click it to start.
echo  The first start downloads the speech model once (about 1.6 GB).
echo.
pause
