"""The brain of Bolo: ties hotkeys, microphone, engine, cleanup and typing together."""
import threading
import time
from datetime import datetime

from PySide6.QtCore import QObject, QTimer, Signal

from . import typer
from .audio import Recorder
from .cleanup import clean
from .engine import Engine
from .hotkeys import Hotkeys
from .meeting import MeetingSession

LANG_CYCLE = ["mix", "en", "hi"]
LANG_LABEL = {"mix": "EN + हि", "en": "EN", "hi": "हि"}
LANG_NAME = {"mix": "English + हिन्दी", "en": "English", "hi": "हिन्दी"}


class Core(QObject):
    # state: idle | loading | listening | writing | done | error
    state_changed = Signal(str, str)
    language_changed = Signal(str)
    dictated = Signal(dict)            # {"text","app","when"}
    meeting_line = Signal(dict)
    meeting_changed = Signal(bool, str)   # running, message / saved path
    meeting_status = Signal(str)
    _type_now = Signal(str, bool, str)
    _meeting_stopped = Signal(str)

    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.engine = Engine(cfg, on_status=self._engine_status)
        self.hotkeys = Hotkeys(cfg)
        self.state = "idle"
        self._rec = None
        self._rec_started = 0.0
        self._app_title = ""
        self.meeting = None
        self.history = []
        self._type_now.connect(self._do_type)
        self._meeting_stopped.connect(self._on_meeting_stopped)
        self.hotkeys.hold_start.connect(self.start_dictation)
        self.hotkeys.hold_stop.connect(self.stop_dictation)
        self.hotkeys.toggle.connect(self.toggle_dictation)
        self.hotkeys.meeting.connect(self.toggle_meeting)

    # -- startup -----------------------------------------------------------
    def start(self):
        try:
            self.hotkeys.start()
        except Exception as e:
            self.state_changed.emit("error", f"Hotkeys unavailable: {e}")
        threading.Thread(target=self._preload, daemon=True).start()

    def _preload(self):
        self._set("loading", "Loading model…")
        try:
            self.engine.preload()
            if self.state == "loading":
                self._set("idle", "")
        except Exception as e:
            self._set("error", f"Model problem: {str(e)[:80]}")

    def _engine_status(self, msg: str):
        if msg:
            self._set("loading", msg)

    def _set(self, state, text=""):
        self.state = state
        self.state_changed.emit(state, text)

    # -- language ------------------------------------------------------------
    def set_language(self, mode: str):
        if mode in LANG_CYCLE and mode != self.cfg["language_mode"]:
            self.cfg.set("language_mode", mode)
        self.language_changed.emit(self.cfg["language_mode"])

    def cycle_language(self):
        cur = self.cfg["language_mode"]
        nxt = LANG_CYCLE[(LANG_CYCLE.index(cur) + 1) % len(LANG_CYCLE)] if cur in LANG_CYCLE else "mix"
        self.set_language(nxt)

    # -- dictation -----------------------------------------------------------
    def level(self) -> float:
        if self._rec is not None:
            return self._rec.level
        return 0.0

    def toggle_dictation(self):
        if self.state == "listening":
            self.stop_dictation()
        else:
            self.start_dictation()

    def start_dictation(self):
        if self.state in ("listening", "writing"):
            return
        try:
            self._rec = Recorder(self.cfg["mic_device"])
            self._rec.start()
        except Exception as e:
            self._rec = None
            self._set("error", f"Microphone problem: {str(e)[:70]}")
            QTimer.singleShot(3000, self._back_to_idle)
            return
        self._rec_started = time.time()
        self._app_title = typer.foreground_title()
        self._set("listening", "Listening…")

    def stop_dictation(self):
        if self.state != "listening" or self._rec is None:
            return
        rec, self._rec = self._rec, None
        audio = rec.stop()
        if time.time() - self._rec_started < 0.35:   # accidental tap
            self._back_to_idle()
            return
        self._set("writing", "Writing…")
        threading.Thread(target=self._work, args=(audio, self._app_title), daemon=True).start()

    def _work(self, audio, app_title):
        try:
            raw = self.engine.transcribe(audio)
            if not raw:
                self._set("error", "Didn't catch that")
                time.sleep(1.4)
                self._set("idle", "")
                return
            text = clean(raw, self.cfg)
            # wait until you let go of the hotkey so Ctrl+V is not mixed with it
            waited = 0.0
            while Hotkeys.modifiers_down() and waited < 1.5:
                time.sleep(0.05)
                waited += 0.05
            self._type_now.emit(text, bool(self.cfg["press_enter"]), app_title or "")
        except Exception as e:
            self._set("error", f"Error: {str(e)[:70]}")
            time.sleep(2.5)
            self._set("idle", "")

    def _do_type(self, text, press_enter, app_title):
        out = text + (" " if self.cfg["trailing_space"] and not text.endswith("\n") else "")
        typer.type_text(out, press_enter)
        item = {"text": text, "app": app_title, "when": datetime.now()}
        self.history.insert(0, item)
        del self.history[30:]
        self.dictated.emit(item)
        words = len(text.split())
        self._set("done", f"Typed {words} word{'s' if words != 1 else ''}")
        QTimer.singleShot(1600, self._back_to_idle)

    def _back_to_idle(self):
        if self.state in ("done", "error", "listening"):
            self._set("idle", "")

    # -- meetings --------------------------------------------------------------
    def toggle_meeting(self):
        if self.meeting is not None and self.meeting.running:
            self.meeting_changed.emit(True, "Finishing the last sentences…")
            threading.Thread(target=self._stop_meeting, daemon=True).start()
        else:
            self._start_meeting()

    def _start_meeting(self):
        self.meeting = MeetingSession(
            self.engine, self.cfg,
            on_line=lambda d: self.meeting_line.emit(d),
            on_status=lambda m: self.meeting_status.emit(m))
        try:
            self.meeting.start()
        except Exception as e:
            self.meeting = None
            self.meeting_status.emit(f"Could not start: {e}")
            self.meeting_changed.emit(False, "")
            return
        self.meeting_changed.emit(True, "Recording")

    def _stop_meeting(self):
        try:
            self.meeting.stop()
            path = str(self.meeting.path or "")
        except Exception as e:
            path = ""
            self.meeting_status.emit(f"Problem while stopping: {e}")
        self._meeting_stopped.emit(path)

    def _on_meeting_stopped(self, path):
        self.meeting_changed.emit(False, path)

    @property
    def meeting_running(self) -> bool:
        return self.meeting is not None and self.meeting.running

    # -- settings changed ----------------------------------------------------------
    def reload_hotkeys(self):
        self.hotkeys.reload()
