"""Builds every screen headlessly (no Windows needed) and runs the dictation and
meeting flows with fake audio / fake speech engine.   python tests/smoke_ui.py"""
import os
import sys
import tempfile
import time
import types

os.environ["QT_QPA_PLATFORM"] = "offscreen"
os.environ["APPDATA"] = tempfile.mkdtemp()
os.environ["HOME"] = tempfile.mkdtemp()
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# --- stand-ins for the Windows-only libraries --------------------------------
fake_kb = types.ModuleType("keyboard")
SENT = []
fake_kb.send = lambda k: SENT.append(k)
fake_kb.is_pressed = lambda k: False
fake_kb.hook = lambda cb: None
fake_kb.add_hotkey = lambda combo, cb: combo
fake_kb.remove_hotkey = lambda h: None
sys.modules["keyboard"] = fake_kb

import numpy as np  # noqa: E402
from PySide6.QtCore import QTimer  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

from bolo import core as core_mod, meeting as meeting_mod, typer  # noqa: E402
from bolo.config import Config  # noqa: E402
from bolo.ui import QSS, FloatingBar, MainWindow, build_tray, make_icon  # noqa: E402

app = QApplication([])
app.setStyleSheet(QSS)
out = sys.argv[1] if len(sys.argv) > 1 else tempfile.mkdtemp()
os.makedirs(out, exist_ok=True)


def pump(seconds):
    end = time.time() + seconds
    while time.time() < end:
        app.processEvents()
        time.sleep(0.01)


class FakeRecorder:
    level = 0.2

    def __init__(self, dev=None):
        pass

    def start(self):
        pass

    def stop(self):
        return (np.random.default_rng(1).standard_normal(16000 * 2) * 0.1).astype(np.float32)


core_mod.Recorder = FakeRecorder
typed = []
typer.type_text = lambda text, enter=False: typed.append((text, enter))
core_mod.typer.foreground_title = lambda: "Outlook"

cfg = Config()
core = core_mod.Core(cfg)
core.engine.preload = lambda: None
core.engine.transcribe = lambda audio: "um kal meeting hai, scratch that. Tuesday, no, Wednesday please send the report"

win = MainWindow(core)
bar = FloatingBar(core, win.show_normal)
win.settings.bar = bar
tray, quit_act = build_tray(app, core, win)
win.show()
bar.show()
pump(0.2)
win.grab().save(f"{out}/1_dictate_idle.png")
bar.grab().save(f"{out}/bar_idle.png")

# --- dictation flow -----------------------------------------------------------
core.start_dictation()
pump(0.3)
assert core.state == "listening", core.state
win.grab().save(f"{out}/1_dictate_listening.png")
bar.grab().save(f"{out}/bar_listening.png")
time.sleep(0.4)
core.stop_dictation()
pump(1.0)
assert typed, "nothing was typed"
print("typed:", typed)
assert typed[0][0].strip() == "Wednesday please send the report", typed[0][0]
win.grab().save(f"{out}/1_dictate_done.png")
bar.grab().save(f"{out}/bar_done.png")
pump(2.0)
assert core.state == "idle", core.state

# language switching
core.cycle_language()
assert cfg["language_mode"] == "en"
core.set_language("mix")
assert win.dictate.seg_btns["mix"].isChecked()

# --- meeting flow with fake audio sources -------------------------------------------
class FakeSource:
    def __init__(self, kind, dev, cb):
        self.kind, self.cb = kind, cb

    def start(self):
        pass

    def stop(self):
        pass


meeting_mod.AudioSource = FakeSource
texts = iter(["Okay so the fieldwork should start next Monday", "Theek hai, main sample plan aaj hi share kar deta hoon",
              "Great, can we also confirm the quota"])
core.engine.transcribe = lambda audio: next(texts, "")
core.toggle_meeting()
pump(0.2)
m = core.meeting
assert m.running
rng = np.random.default_rng(2)
now = time.time()
m._seg_sys.on_utterance(rng.standard_normal(16000).astype(np.float32), now)
m._seg_mic.on_utterance(rng.standard_normal(16000).astype(np.float32), now + 2)
m._seg_sys.on_utterance(rng.standard_normal(16000).astype(np.float32), now + 5)
pump(1.5)
core.toggle_meeting()
pump(3)
assert not core.meeting_running
txt = open(m.path, encoding="utf-8-sig").read()
print(txt)
assert "Others: Okay so the fieldwork" in txt and "You: Theek hai" in txt
m.save_docx(os.path.join(out, "t.docx"))
win.show_page(1)
pump(0.2)
win.grab().save(f"{out}/2_meeting.png")
win.show_page(2)
pump(0.2)
win.grab().save(f"{out}/3_settings.png")
make_icon("app").pixmap(96, 96).save(f"{out}/icon.png")
print("SMOKE OK ->", out)
