"""Meeting transcription: your microphone (= "You") plus everything the PC plays
(= "Others"). Works with Teams in the browser or the Teams app, Zoom, Meet...
"""
import difflib
import queue
import threading
import time
from datetime import datetime

from .audio import AudioSource
from .cleanup import clean
from .config import meetings_dir
from .segmenter import Segmenter


def fmt_time(seconds: float) -> str:
    s = max(0, int(seconds))
    return f"{s // 3600:02d}:{(s % 3600) // 60:02d}:{s % 60:02d}"


class MeetingSession:
    def __init__(self, engine, cfg, on_line, on_status):
        self.engine = engine
        self.cfg = cfg
        self.on_line = on_line          # called with {"t","time","speaker","text"}
        self.on_status = on_status      # called with a short message
        self.lines = []
        self.running = False
        self.path = None
        self._q = queue.Queue()
        self._threads = []
        self._mic = None
        self._loop = None
        self._seg_mic = None
        self._seg_sys = None
        self._t0 = 0.0
        self._lines_lock = threading.Lock()

    # -- control ---------------------------------------------------------
    def start(self):
        self._t0 = time.time()
        self.path = meetings_dir() / f"Meeting_{datetime.now():%Y%m%d_%H%M}.txt"
        self._seg_mic = Segmenter(lambda a, t: self._q.put(("You", a, t)))
        self._seg_sys = Segmenter(lambda a, t: self._q.put(("Others", a, t)))
        self._mic = AudioSource("mic", self.cfg["mic_device"], self._seg_mic.feed)
        self._mic.start()
        try:
            self._loop = AudioSource("loopback", None, self._seg_sys.feed)
            self._loop.start()
        except Exception as e:  # keep going with the mic only
            self._loop = None
            self.on_status(f"Could not capture the other side of the call: {e}")
        self.running = True
        for target in (self._worker, self._ticker, self._autosave):
            th = threading.Thread(target=target, daemon=True)
            th.start()
            self._threads.append(th)

    def stop(self):
        if not self.running:
            return
        for src in (self._mic, self._loop):
            if src is not None:
                src.stop()
        self._seg_mic.flush()
        self._seg_sys.flush()
        self.running = False
        self._q.put(None)  # wake the worker
        self._threads[0].join(timeout=120)  # let queued speech finish
        self.save_txt()

    @property
    def elapsed(self) -> float:
        return time.time() - self._t0 if self.running else 0.0

    # -- background threads ---------------------------------------------
    def _ticker(self):
        while self.running:
            self._seg_mic.tick()
            self._seg_sys.tick()
            time.sleep(0.25)

    def _autosave(self):
        n = 0
        while self.running:
            time.sleep(1)
            n += 1
            if n % 30 == 0:
                self.save_txt()

    def _worker(self):
        while True:
            try:
                item = self._q.get(timeout=0.5)
            except queue.Empty:
                if not self.running and self._q.empty():
                    return
                continue
            if item is None:
                if self._q.empty():
                    return
                continue
            speaker, audio, start = item
            try:
                raw = self.engine.transcribe(audio)
                text = clean(raw, self.cfg, voice_commands=False)
            except Exception as e:
                self.on_status(f"Transcription problem: {e}")
                continue
            if not text:
                continue
            t = max(0.0, start - self._t0)
            if speaker == "You" and self._is_echo(text, t):
                continue  # your mic picked up the speakers; keep only "Others"
            line = {"t": t, "time": fmt_time(t), "speaker": speaker, "text": text}
            with self._lines_lock:
                self.lines.append(line)
                self.lines.sort(key=lambda d: d["t"])
            self.on_line(line)

    def _is_echo(self, text: str, t: float) -> bool:
        with self._lines_lock:
            recent = [l for l in self.lines if l["speaker"] == "Others" and abs(l["t"] - t) < 12]
        a = text.lower()
        return any(difflib.SequenceMatcher(None, a, l["text"].lower()).ratio() > 0.75
                   for l in recent)

    # -- saving ----------------------------------------------------------
    def as_text(self) -> str:
        head = f"Meeting transcript - {datetime.fromtimestamp(self._t0 or time.time()):%d %b %Y, %H:%M}\n"
        with self._lines_lock:
            body = "\n".join(f"[{l['time']}] {l['speaker']}: {l['text']}" for l in self.lines)
        return head + "\n" + body + "\n"

    def save_txt(self, path=None):
        path = path or self.path
        if path is None:
            return None
        try:
            with open(path, "w", encoding="utf-8-sig") as f:
                f.write(self.as_text())
        except OSError:
            return None
        return path

    def save_docx(self, path):
        from docx import Document
        doc = Document()
        doc.add_heading("Meeting transcript", level=1)
        doc.add_paragraph(f"{datetime.fromtimestamp(self._t0 or time.time()):%d %b %Y, %H:%M}")
        with self._lines_lock:
            lines = list(self.lines)
        for l in lines:
            p = doc.add_paragraph()
            r = p.add_run(f"[{l['time']}] {l['speaker']}: ")
            r.bold = True
            p.add_run(l["text"])
        doc.save(path)
        return path
