# Bolo – speak, it types (English + Hindi)

Free. Offline. No account, no subscription, no limit on how much you dictate.

* **Dictation anywhere** – hold **Ctrl + Win**, speak, let go. The text is typed where your cursor is (Outlook, Word, Teams chat, browser, anything).
* **English, Hindi, or both in one sentence** – "Kal ki meeting 11 baje hai, please send me the report."
* **Clean text** – no "umm/uh", capitals, corrections ("Tuesday, no, Wednesday" → "Wednesday"), "scratch that", "new line".
* **Meeting transcript** – press **Record meeting** (or Ctrl + Alt + M). Your microphone is labelled **You**, everything the PC plays (the other people on Teams, in the browser or the app) is labelled **Others**. Saved automatically to `Documents\Bolo\Meetings`, export to .txt or .docx.
* **Control buttons** – a small floating bar (mic button + language chip) and a tray icon near the clock. Click the language chip to switch English → हिन्दी → English + हिन्दी. Click the tray icon to open the full app.

## Install (once, ~10 minutes)

1. Install **Python 3.12** from python.org. Tick **"Add python.exe to PATH"**.
2. Unzip this folder somewhere permanent (e.g. `C:\Bolo`).
3. Double-click **install.bat**. It installs everything and puts a **Bolo** shortcut on your Desktop.
4. Double-click **Bolo**. The first start downloads the speech model once (needs internet, ~1.6 GB). After that it works offline.

## Use

| Action | How |
|---|---|
| Dictate (hold) | Hold **Ctrl + Win**, speak, release |
| Dictate (hands-free) | **Ctrl + Alt + Space** to start, again to stop |
| Record a meeting | **Ctrl + Alt + M**, or the Record button |
| Change language | Click the chip on the floating bar, or tray icon → Language |
| Open the app | Click the tray icon, or the **B** button on the bar |

All shortcuts can be changed in **Settings**.

## Hindi in English letters or in Devanagari

**Settings → How Hindi is written.** *Hinglish* gives "Kal meeting hai", *Devanagari* gives "कल meeting है". English words always stay in English.

## Accuracy vs. speed (Settings → Accuracy)

| Level | Model | Download | Notes |
|---|---|---|---|
| Fast | small | ~0.5 GB | quick, fine for English, weaker Hindi |
| **Balanced** (default) | large-v3-turbo | ~1.6 GB | good Hindi + English |
| Best | large-v3 | ~3 GB | clearest, wants a stronger PC |

An NVIDIA graphics card makes it much faster. If Bolo finds one it uses it; if the CUDA libraries are missing it quietly falls back to the CPU. To enable the GPU: `venv\Scripts\pip install nvidia-cublas-cu12 nvidia-cudnn-cu12==9.*`.

Tip: **Settings → My words & names** teaches Bolo your spellings (e.g. `ken research => Ken Research`). They are also fed to the speech model, which helps with names and jargon.

## Good to know

* **Wait for "Listening…"** on the bar before the first word (the microphone takes a split second to open).
* **Teams, Zoom, Meet, YouTube** – the "Others" side captures *all* sound the PC plays, so close music or videos during a call.
* **Use a headset** for meetings; with speakers your mic can hear the other side too (Bolo hides most of these echoes).
* **Typing into an app running "as administrator"** needs Bolo started as administrator too (a Windows rule).
* While typing, Bolo briefly uses the clipboard (the only way to type Hindi reliably in every app) and then restores what was there. Pictures and files on the clipboard may not come back.
* **Consent** – tell participants when you transcribe a call; some companies and countries require it.
* Your voice never leaves the PC. Transcripts are plain files in `Documents\Bolo\Meetings`; settings are in `%APPDATA%\Bolo`.

## For developers

```
bolo/
  app.py       start-up, tray, single instance
  ui.py        main window, floating bar, tray menu (PySide6)
  core.py      state machine: hotkey -> record -> transcribe -> clean -> type
  engine.py    faster-whisper (Hinglish / Devanagari prompting, GPU->CPU fallback)
  cleanup.py   fillers, corrections, voice commands, dictionary, capitals
  translit.py  Devanagari -> Roman safety net
  audio.py     WASAPI mic + loopback capture (PyAudioWPatch)
  segmenter.py cuts a live stream into utterances
  meeting.py   two-stream meeting transcript, echo filter, .txt/.docx export
  hotkeys.py   global hold / toggle hotkeys
  typer.py     Ctrl+V typing with clipboard restore
tests/run_tests.py   cleanup / transliteration / segmenter tests
tests/smoke_ui.py    headless UI + dictation + meeting flow with fake audio
```
