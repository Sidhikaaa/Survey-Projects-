"""Bolo's screens: main window, floating bar and tray menu (PySide6 / Qt)."""
import html
import threading
from collections import deque
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, QSize, Qt, QTimer, QUrl
from PySide6.QtGui import (QAction, QActionGroup, QColor, QDesktopServices, QGuiApplication,
                           QIcon, QPainter, QPen, QPixmap)
from PySide6.QtWidgets import (QApplication, QButtonGroup, QCheckBox, QComboBox, QDialog,
                               QFileDialog, QFrame, QGridLayout, QHBoxLayout, QLabel,
                               QLineEdit, QMenu, QMessageBox, QPlainTextEdit, QPushButton,
                               QRadioButton, QScrollArea, QStackedWidget, QSystemTrayIcon,
                               QTextBrowser, QVBoxLayout, QWidget)

from . import audio
from .config import meetings_dir, set_autostart
from .core import LANG_CYCLE, LANG_LABEL, LANG_NAME

INK, MUTED, LINE, BG = "#12161F", "#566074", "#E1E5EC", "#F3F5F8"
ACCENT, ACCENT_SOFT, REC = "#3B3FD8", "#E8E9FB", "#D63A3A"

QSS = f"""
QWidget {{ font-family: "Segoe UI", "Nirmala UI", sans-serif; font-size: 14px; color: {INK}; }}
#root {{ background: {BG}; }}
#sidebar {{ background: #FFFFFF; border-right: 1px solid {LINE}; }}
QPushButton#nav {{ text-align: left; padding: 10px 14px; border: 0; border-radius: 10px;
  color: #3A4254; font-weight: 600; background: transparent; }}
QPushButton#nav:checked {{ background: {ACCENT_SOFT}; color: #2B2FB8; }}
QPushButton#nav:hover:!checked {{ background: {BG}; }}
#card {{ background: #FFFFFF; border: 1px solid {LINE}; border-radius: 16px; }}
#row {{ background: #FFFFFF; border: 1px solid {LINE}; border-radius: 14px; }}
#h1 {{ font-size: 26px; font-weight: 700; }}
#h2 {{ font-size: 16px; font-weight: 600; }}
#muted {{ color: {MUTED}; }}
#caption {{ color: {MUTED}; font-size: 12px; font-weight: 600; }}
#segWrap {{ background: {BG}; border-radius: 12px; }}
QPushButton#seg {{ border: 0; padding: 8px 16px; border-radius: 9px; background: transparent;
  color: #3A4254; font-weight: 600; min-height: 20px; }}
QPushButton#seg:checked {{ background: {ACCENT}; color: #FFFFFF; }}
QPushButton#bigMic {{ border: 0; border-radius: 56px; background: {ACCENT}; }}
QPushButton#bigMic[state="listening"] {{ background: {REC}; }}
QPushButton#bigMic[state="loading"], QPushButton#bigMic[state="writing"] {{ background: #8A93A5; }}
QPushButton#bigMic[state="done"] {{ background: #1E6B45; }}
QPushButton#secondary {{ border: 1px solid #D5DAE3; border-radius: 10px; padding: 0 16px;
  min-height: 40px; background: #FFFFFF; font-weight: 600; }}
QPushButton#secondary:hover {{ background: {BG}; }}
QPushButton#copy {{ border: 1px solid {LINE}; border-radius: 10px; padding: 0 12px;
  min-height: 34px; background: #FFFFFF; color: #3A4254; font-weight: 600; }}
QPushButton#record {{ border: 0; border-radius: 12px; padding: 0 22px; min-height: 44px;
  background: {REC}; color: #FFFFFF; font-weight: 600; }}
QPushButton#record[running="true"] {{ background: {INK}; }}
#pillStatus {{ padding: 8px 14px; border-radius: 18px; background: {LINE}; color: #3A4254;
  font-weight: 600; font-size: 13px; }}
#pillStatus[running="true"] {{ background: #FDECEC; color: #A82626; }}
QTextBrowser {{ border: 0; background: #FFFFFF; font-size: 15px; }}
QLineEdit, QComboBox, QPlainTextEdit {{ border: 1px solid #D5DAE3; border-radius: 8px;
  padding: 6px 10px; background: #FFFFFF; }}
QRadioButton, QCheckBox {{ spacing: 10px; }}
#pill {{ background: {INK}; border-radius: 28px; }}
#pill QLabel {{ color: #FFFFFF; font-weight: 600; }}
QPushButton#barMic {{ border: 0; border-radius: 20px; background: {ACCENT}; }}
QPushButton#barMic[state="listening"] {{ background: {REC}; }}
QPushButton#barMic[state="loading"], QPushButton#barMic[state="writing"] {{ background: #4A5266; }}
QPushButton#barMic[state="done"] {{ background: #1E6B45; }}
QPushButton#barMic[state="error"] {{ background: #8A5A00; }}
QPushButton#chip {{ border: 1px solid #3A4254; border-radius: 18px; color: #FFFFFF; padding: 0 14px;
  min-height: 36px; background: transparent; font-weight: 600; }}
QPushButton#chip:hover {{ background: #232A3A; }}
QPushButton#openBtn {{ border: 0; border-radius: 16px; background: #232A3A; color: #FFFFFF;
  min-width: 32px; max-width: 32px; min-height: 32px; max-height: 32px; font-weight: 700; }}
"""


# ---------------------------------------------------------------- icons ---
def make_icon(kind: str, color: str = "#FFFFFF") -> QIcon:
    S = 96
    pm = QPixmap(S, S)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    pen = QPen(QColor(color), 6.5)
    pen.setCapStyle(Qt.RoundCap)
    pen.setJoinStyle(Qt.RoundJoin)
    p.setPen(pen)
    if kind == "mic":
        p.drawRoundedRect(QRectF(36, 12, 24, 44), 12, 12)
        p.drawArc(QRectF(20, 20, 56, 56), 180 * 16, 180 * 16)
        p.drawLine(QPointF(48, 76), QPointF(48, 86))
    elif kind == "stop":
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(color))
        p.drawRoundedRect(QRectF(30, 30, 36, 36), 6, 6)
    elif kind == "check":
        p.drawPolyline([QPointF(22, 50), QPointF(40, 68), QPointF(76, 28)])
    elif kind == "app":
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(ACCENT))
        p.drawRoundedRect(QRectF(4, 4, 88, 88), 22, 22)
        pen.setColor(QColor("#FFFFFF"))
        pen.setWidthF(7)
        p.setPen(pen)
        for x, h in ((24, 14), (36, 32), (48, 42), (60, 26), (72, 12)):
            p.drawLine(QPointF(x, 48 - h / 2), QPointF(x, 48 + h / 2))
    p.end()
    return QIcon(pm)


def pretty_combo(combo: str) -> str:
    return " + ".join(p.strip().capitalize() if len(p.strip()) > 1 else p.strip().upper()
                      for p in combo.split("+") if p.strip())


def ago(when: datetime) -> str:
    s = int((datetime.now() - when).total_seconds())
    if s < 60:
        return "just now"
    if s < 3600:
        return f"{s // 60} min ago"
    return f"{s // 3600} hr ago"


def _repolish(w: QWidget):
    w.style().unpolish(w)
    w.style().polish(w)
    w.update()


def _lbl(text="", name=None, wrap=False) -> QLabel:
    l = QLabel(text)
    if name:
        l.setObjectName(name)
    l.setWordWrap(wrap)
    return l


def _card() -> QFrame:
    f = QFrame()
    f.setObjectName("card")
    return f


# -------------------------------------------------------- floating bar ---
class WaveWidget(QWidget):
    def __init__(self, level_fn, color="#FF8A8A", bars=14):
        super().__init__()
        self.level_fn = level_fn
        self.color = QColor(color)
        self.hist = deque([0.0] * bars, maxlen=bars)
        self.setFixedSize(bars * 7, 28)

    def tick(self):
        self.hist.append(min(1.0, self.level_fn() * 14))
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(Qt.NoPen)
        p.setBrush(self.color)
        for i, v in enumerate(self.hist):
            h = 5 + v * 22
            p.drawRoundedRect(QRectF(i * 7, (28 - h) / 2, 3.5, h), 1.7, 1.7)


class FloatingBar(QWidget):
    """Small always-on-top pill. It never takes keyboard focus, so the app you
    are typing in keeps the cursor while you click it."""

    def __init__(self, core, open_main):
        super().__init__(None, Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool
                         | Qt.WindowDoesNotAcceptFocus)
        self.core = core
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self._moved = False
        self._drag = None

        outer = QHBoxLayout(self)
        outer.setContentsMargins(6, 6, 6, 6)
        self.pill = QFrame()
        self.pill.setObjectName("pill")
        outer.addWidget(self.pill)
        lay = QHBoxLayout(self.pill)
        lay.setContentsMargins(8, 8, 12, 8)
        lay.setSpacing(10)

        self.btn = QPushButton()
        self.btn.setObjectName("barMic")
        self.btn.setFixedSize(40, 40)
        self.btn.setIconSize(QSize(20, 20))
        self.btn.setToolTip("Start / stop dictating")
        self.btn.clicked.connect(core.toggle_dictation)
        self.wave = WaveWidget(core.level)
        self.label = QLabel("")
        self.chip = QPushButton(LANG_LABEL[core.cfg["language_mode"]])
        self.chip.setObjectName("chip")
        self.chip.setToolTip("Change language: English / हिन्दी / English + हिन्दी")
        self.chip.clicked.connect(core.cycle_language)
        self.open_btn = QPushButton("B")
        self.open_btn.setObjectName("openBtn")
        self.open_btn.setToolTip("Open Bolo")
        self.open_btn.clicked.connect(open_main)
        for w in (self.btn, self.wave, self.label, self.chip, self.open_btn):
            lay.addWidget(w)

        self._timer = QTimer(self)
        self._timer.setInterval(45)
        self._timer.timeout.connect(self.wave.tick)

        core.state_changed.connect(self.on_state)
        core.language_changed.connect(lambda m: self.chip.setText(LANG_LABEL[m]))
        self.on_state("idle", "")

    def on_state(self, state, text):
        self.btn.setProperty("state", state)
        self.btn.setIcon(make_icon({"listening": "stop", "done": "check"}.get(state, "mic")))
        _repolish(self.btn)
        listening = state == "listening"
        self.wave.setVisible(listening)
        (self._timer.start if listening else self._timer.stop)()
        self.label.setVisible(state != "idle" and bool(text))
        self.label.setText(text)
        self.chip.setVisible(state == "idle")
        self.open_btn.setVisible(state == "idle")
        self.adjustSize()
        self._place()

    def _place(self):
        if self._moved:
            return
        scr = QGuiApplication.primaryScreen().availableGeometry()
        self.move(scr.center().x() - self.width() // 2, scr.bottom() - self.height() - 18)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._drag = e.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, e):
        if self._drag is not None and e.buttons() & Qt.LeftButton:
            self._moved = True
            self.move(e.globalPosition().toPoint() - self._drag)

    def mouseReleaseEvent(self, _):
        self._drag = None


# ---------------------------------------------------------------- pages ---
class DictatePage(QWidget):
    def __init__(self, core):
        super().__init__()
        self.core = core
        cfg = core.cfg
        root = QVBoxLayout(self)
        root.setContentsMargins(40, 32, 40, 24)
        root.setSpacing(20)

        root.addWidget(_lbl("Speak. Bolo types.", "h1"))
        self.sub = _lbl("", "muted", True)
        root.addWidget(self.sub)

        card = _card()
        h = QHBoxLayout(card)
        h.setContentsMargins(28, 24, 28, 24)
        h.setSpacing(28)
        self.mic = QPushButton()
        self.mic.setObjectName("bigMic")
        self.mic.setFixedSize(112, 112)
        self.mic.setIconSize(QSize(46, 46))
        self.mic.setCursor(Qt.PointingHandCursor)
        self.mic.clicked.connect(core.toggle_dictation)
        h.addWidget(self.mic)

        col = QVBoxLayout()
        col.setSpacing(10)
        self.mic_title = _lbl("", "h2")
        self.mic_sub = _lbl("", "muted", True)
        self.wave = WaveWidget(core.level, "#D63A3A")
        self.wave.hide()
        col.addWidget(self.mic_title)
        col.addWidget(self.mic_sub)
        col.addWidget(self.wave)
        col.addSpacing(4)
        col.addWidget(_lbl("LANGUAGE", "caption"))
        seg = QFrame()
        seg.setObjectName("segWrap")
        sl = QHBoxLayout(seg)
        sl.setContentsMargins(4, 4, 4, 4)
        sl.setSpacing(2)
        self.group = QButtonGroup(self)
        self.group.setExclusive(True)
        self.seg_btns = {}
        for mode in ("en", "hi", "mix"):
            b = QPushButton(LANG_NAME[mode])
            b.setObjectName("seg")
            b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, m=mode: core.set_language(m))
            self.group.addButton(b)
            self.seg_btns[mode] = b
            sl.addWidget(b)
        segrow = QHBoxLayout()
        segrow.addWidget(seg)
        segrow.addStretch(1)
        col.addLayout(segrow)
        h.addLayout(col, 1)
        root.addWidget(card)

        head = QHBoxLayout()
        head.addWidget(_lbl("Recent dictations", "h2"))
        head.addStretch(1)
        head.addWidget(_lbl("Kept in memory only, cleared when you quit", "muted"))
        root.addLayout(head)
        self.rows = QVBoxLayout()
        self.rows.setSpacing(10)
        root.addLayout(self.rows)
        self.empty = _lbl("Nothing yet. Hold the hotkey and say something.", "muted")
        self.rows.addWidget(self.empty)
        root.addStretch(1)

        self._timer = QTimer(self)
        self._timer.setInterval(45)
        self._timer.timeout.connect(self.wave.tick)
        core.state_changed.connect(self.on_state)
        core.language_changed.connect(self.on_language)
        core.dictated.connect(self.on_dictated)
        self.refresh_text()
        self.on_language(cfg["language_mode"])
        self.on_state("idle", "")

    def refresh_text(self):
        hk = pretty_combo(self.core.cfg["hotkey_hold"])
        self.sub.setText(f"Hold <b>{hk}</b> in any app, speak in English, Hindi or both, and let "
                         f"go. The text appears where your cursor is.")

    def on_language(self, mode):
        if mode in self.seg_btns:
            self.seg_btns[mode].setChecked(True)

    def on_state(self, state, text):
        self.mic.setProperty("state", state)
        self.mic.setIcon(make_icon({"listening": "stop", "done": "check"}.get(state, "mic")))
        _repolish(self.mic)
        hk = pretty_combo(self.core.cfg["hotkey_hold"])
        titles = {
            "idle": (f"Click to start, or hold {hk}",
                     "Bolo types into the app you are using, with punctuation and no “umm”."),
            "loading": ("Getting ready…", text or "Loading the speech model."),
            "listening": ("Listening… speak now", "Click again (or let go of the keys) to stop."),
            "writing": ("Writing…", "Turning your voice into text."),
            "done": (text or "Done", "Typed at your cursor."),
            "error": ("Something went wrong", text),
        }
        t, s = titles.get(state, titles["idle"])
        self.mic_title.setText(t)
        self.mic_sub.setText(s)
        self.wave.setVisible(state == "listening")
        (self._timer.start if state == "listening" else self._timer.stop)()

    def on_dictated(self, item):
        self.empty.hide()
        row = QFrame()
        row.setObjectName("row")
        h = QHBoxLayout(row)
        h.setContentsMargins(16, 12, 12, 12)
        h.setSpacing(14)
        t = _lbl(item["text"].replace("\n", " ⏎ "), None, True)
        t.setTextInteractionFlags(Qt.TextSelectableByMouse)
        meta = _lbl(" · ".join(x for x in (item["app"], ago(item["when"])) if x), "muted")
        cp = QPushButton("Copy")
        cp.setObjectName("copy")
        cp.clicked.connect(lambda: QGuiApplication.clipboard().setText(item["text"]))
        h.addWidget(t, 1)
        h.addWidget(meta)
        h.addWidget(cp)
        self.rows.insertWidget(0, row)
        while self.rows.count() > 6:
            w = self.rows.takeAt(self.rows.count() - 2).widget()
            if w is not None:
                w.deleteLater()


class MeetingPage(QWidget):
    def __init__(self, core):
        super().__init__()
        self.core = core
        root = QVBoxLayout(self)
        root.setContentsMargins(36, 28, 36, 24)
        root.setSpacing(18)

        top = QHBoxLayout()
        tcol = QVBoxLayout()
        tcol.setSpacing(4)
        tcol.addWidget(_lbl("Meeting transcript", "h1"))
        tcol.addWidget(_lbl("Works with Teams in the browser or the Teams app. "
                            "Press Record, then talk as usual.", "muted", True))
        top.addLayout(tcol, 1)
        self.status = _lbl("Ready", "pillStatus")
        self.status.setProperty("running", "false")
        self.rec = QPushButton("Record meeting")
        self.rec.setObjectName("record")
        self.rec.setProperty("running", "false")
        self.rec.setCursor(Qt.PointingHandCursor)
        self.rec.clicked.connect(core.toggle_meeting)
        top.addWidget(self.status)
        top.addSpacing(10)
        top.addWidget(self.rec)
        root.addLayout(top)

        body = QHBoxLayout()
        body.setSpacing(18)
        left = _card()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)
        lv.setSpacing(0)
        hd = QHBoxLayout()
        hd.setContentsMargins(20, 14, 20, 14)
        hd.addWidget(_lbl("Live transcript", "h2"))
        hd.addStretch(1)
        hd.addWidget(_lbl("English + हिन्दी · auto-detected", "muted"))
        lv.addLayout(hd)
        self.view = QTextBrowser()
        self.view.setOpenLinks(False)
        self.view.setPlaceholderText("The conversation will appear here while the meeting is recorded.")
        lv.addWidget(self.view, 1)
        ft = QHBoxLayout()
        ft.setContentsMargins(16, 12, 16, 12)
        for text, fn in (("Copy all", self.copy_all), ("Save as .txt", self.save_txt),
                         ("Save as .docx", self.save_docx), ("Open folder", self.open_folder)):
            b = QPushButton(text)
            b.setObjectName("secondary")
            b.clicked.connect(fn)
            ft.addWidget(b)
        ft.addStretch(1)
        self.note = _lbl("Auto-saved every 30 seconds", "muted")
        ft.addWidget(self.note)
        lv.addLayout(ft)
        body.addWidget(left, 3)

        right = QVBoxLayout()
        right.setSpacing(14)
        c1 = _card()
        v1 = QVBoxLayout(c1)
        v1.setContentsMargins(18, 16, 18, 16)
        v1.setSpacing(8)
        v1.addWidget(_lbl("What is being recorded", "h2"))
        v1.addWidget(_lbl("<b>You</b> = your microphone<br><b>Others</b> = everything you hear "
                          "on this PC (the other people in the call)", None, True))
        v1.addWidget(_lbl("Wear a headset: with speakers, your mic can pick up the other "
                          "side twice.", "muted", True))
        right.addWidget(c1)
        c2 = _card()
        v2 = QVBoxLayout(c2)
        v2.setContentsMargins(18, 16, 18, 16)
        v2.setSpacing(8)
        v2.addWidget(_lbl("Please note", "h2"))
        v2.addWidget(_lbl("Tell participants you are transcribing the call. Some companies and "
                          "countries require consent to record.", "muted", True))
        right.addWidget(c2)
        right.addStretch(1)
        wrap = QWidget()
        wrap.setLayout(right)
        wrap.setFixedWidth(270)
        body.addWidget(wrap)
        root.addLayout(body, 1)

        self._clock = QTimer(self)
        self._clock.setInterval(1000)
        self._clock.timeout.connect(self._tick)
        core.meeting_line.connect(self.add_line)
        core.meeting_changed.connect(self.on_changed)
        core.meeting_status.connect(lambda m: self.note.setText(m))

    def _tick(self):
        m = self.core.meeting
        if m is not None and m.running:
            s = int(m.elapsed)
            self.status.setText(f"Recording · {s // 3600:02d}:{(s % 3600) // 60:02d}:{s % 60:02d}")

    def on_changed(self, running, msg):
        if running and msg == "Recording":
            self.view.clear()
            self._clock.start()
        flag = "true" if running else "false"
        for w in (self.status, self.rec):
            w.setProperty("running", flag)
            _repolish(w)
        self.rec.setText("Stop" if running else "Record meeting")
        if running:
            self.status.setText("Recording · 00:00:00" if msg == "Recording" else msg)
        else:
            self._clock.stop()
            self.status.setText("Ready")
            if msg:
                self.note.setText(f"Saved: {msg}")

    def add_line(self, d):
        who = d["speaker"]
        color = "#2B2FB8" if who == "You" else MUTED
        self.view.append(
            f'<p style="margin:0 0 12px 0"><span style="color:{MUTED};font-size:12px">{d["time"]}'
            f'</span> <b style="color:{color};font-size:12px">{who.upper()}</b><br>'
            f'{html.escape(d["text"])}</p>')

    def _text(self):
        m = self.core.meeting
        return m.as_text() if m is not None else ""

    def copy_all(self):
        QGuiApplication.clipboard().setText(self._text())
        self.note.setText("Copied")

    def save_txt(self):
        if not self._text():
            return
        path, _ = QFileDialog.getSaveFileName(self, "Save transcript",
                                              str(meetings_dir() / "Transcript.txt"),
                                              "Text (*.txt)")
        if path:
            self.core.meeting.save_txt(path)
            self.note.setText(f"Saved: {path}")

    def save_docx(self):
        if not self._text():
            return
        path, _ = QFileDialog.getSaveFileName(self, "Save transcript",
                                              str(meetings_dir() / "Transcript.docx"),
                                              "Word (*.docx)")
        if path:
            try:
                self.core.meeting.save_docx(path)
                self.note.setText(f"Saved: {path}")
            except Exception as e:
                QMessageBox.warning(self, "Bolo", f"Could not save the Word file:\n{e}")

    def open_folder(self):
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(meetings_dir())))


class DictionaryDialog(QDialog):
    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.setWindowTitle("My words & names")
        self.resize(460, 360)
        v = QVBoxLayout(self)
        v.addWidget(_lbl("One per line, written as  heard => written.\n"
                         "Example:  ken research => Ken Research", "muted", True))
        self.edit = QPlainTextEdit()
        self.edit.setPlainText("\n".join(f"{a} => {b}" for a, b in cfg["dictionary"]))
        v.addWidget(self.edit, 1)
        row = QHBoxLayout()
        row.addStretch(1)
        ok = QPushButton("Save")
        ok.setObjectName("secondary")
        ok.clicked.connect(self.accept)
        row.addWidget(ok)
        v.addLayout(row)

    def accept(self):
        pairs = []
        for line in self.edit.toPlainText().splitlines():
            if "=>" in line:
                a, b = line.split("=>", 1)
                if a.strip():
                    pairs.append([a.strip(), b.strip()])
        self.cfg.set("dictionary", pairs)
        super().accept()


class SettingsPage(QWidget):
    def __init__(self, core, on_hotkeys_changed):
        super().__init__()
        self.core, self.cfg = core, core.cfg
        self.on_hotkeys_changed = on_hotkeys_changed
        outer = QVBoxLayout(self)
        outer.setContentsMargins(36, 28, 36, 0)
        outer.addWidget(_lbl("Settings", "h1"))
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("QScrollArea { background: transparent; }")
        scroll.viewport().setAutoFillBackground(False)
        inner = QWidget()
        inner.setAutoFillBackground(False)
        scroll.setWidget(inner)
        grid = QGridLayout(inner)
        grid.setContentsMargins(0, 12, 8, 24)
        grid.setSpacing(16)
        outer.addWidget(scroll, 1)
        cfg = self.cfg

        # -- Hindi script
        c = _card()
        v = QVBoxLayout(c)
        v.setContentsMargins(18, 16, 18, 16)
        v.setSpacing(10)
        v.addWidget(_lbl("How Hindi is written", "h2"))
        self.script_group = QButtonGroup(self)
        for key, text in (("hinglish", "Hinglish (English letters)\nKal meeting hai, please send the report"),
                          ("devanagari", "Devanagari (हिन्दी script)\nकल meeting है, please send the report")):
            r = QRadioButton(text)
            r.setChecked(cfg["hindi_script"] == key)
            r.toggled.connect(lambda on, k=key: on and cfg.set("hindi_script", k))
            self.script_group.addButton(r)
            v.addWidget(r)
        grid.addWidget(c, 0, 0, Qt.AlignTop)

        # -- accuracy
        c = _card()
        v = QVBoxLayout(c)
        v.setContentsMargins(18, 16, 18, 16)
        v.setSpacing(10)
        v.addWidget(_lbl("Accuracy", "h2"))
        self.acc_group = QButtonGroup(self)
        for key, text in (
                ("fast", "Fast\nSmall model. Quick, works on any laptop. (~0.5 GB download)"),
                ("balanced", "Balanced\nGood Hindi and English, recommended. (~1.6 GB download)"),
                ("best", "Best\nLarge model. Clearest text, needs a stronger PC. (~3 GB download)")):
            r = QRadioButton(text)
            r.setChecked(cfg["accuracy"] == key)
            r.toggled.connect(lambda on, k=key: on and self._set_accuracy(k))
            self.acc_group.addButton(r)
            v.addWidget(r)
        grid.addWidget(c, 0, 1, Qt.AlignTop)

        # -- clean text
        c = _card()
        v = QVBoxLayout(c)
        v.setContentsMargins(18, 16, 18, 16)
        v.setSpacing(10)
        v.addWidget(_lbl("Make the text clean", "h2"))
        for key, text in (("remove_fillers", "Remove “umm”, “uh”, “hmm”"),
                          ("capitalize", "Add capitals (start of sentences, “I”)"),
                          ("follow_corrections", "Follow corrections (“Tuesday, no, Wednesday”, “scratch that”)"),
                          ("press_enter", "Press Enter automatically after typing"),
                          ("trailing_space", "Add a space after each dictation")):
            cb = QCheckBox(text)
            cb.setChecked(bool(cfg[key]))
            cb.toggled.connect(lambda on, k=key: cfg.set(k, bool(on)))
            v.addWidget(cb)
        b = QPushButton("My words && names…")
        b.setObjectName("secondary")
        b.clicked.connect(lambda: DictionaryDialog(cfg, self).exec())
        row = QHBoxLayout()
        row.addWidget(b)
        row.addStretch(1)
        v.addLayout(row)
        grid.addWidget(c, 1, 0, Qt.AlignTop)

        # -- shortcuts & devices
        c = _card()
        v = QVBoxLayout(c)
        v.setContentsMargins(18, 16, 18, 16)
        v.setSpacing(10)
        v.addWidget(_lbl("Shortcuts and devices", "h2"))
        self.hk_edits = {}
        for key, text in (("hotkey_hold", "Hold to speak"),
                          ("hotkey_toggle", "Start / stop (hands-free)"),
                          ("hotkey_meeting", "Record meeting")):
            v.addWidget(_lbl(text, "caption"))
            e = QLineEdit(cfg[key])
            e.editingFinished.connect(lambda k=key, ed=e: self._set_hotkey(k, ed.text()))
            self.hk_edits[key] = e
            v.addWidget(e)
        v.addWidget(_lbl("Use: ctrl, alt, shift, windows, space, f9 … joined with +", "muted", True))
        v.addWidget(_lbl("Microphone", "caption"))
        self.mic_box = QComboBox()
        self.mic_box.addItem("Windows default", None)
        for idx, name in audio.list_inputs():
            self.mic_box.addItem(name, idx)
        i = self.mic_box.findData(cfg["mic_device"])
        self.mic_box.setCurrentIndex(max(0, i))
        self.mic_box.currentIndexChanged.connect(
            lambda _i: cfg.set("mic_device", self.mic_box.currentData()))
        v.addWidget(self.mic_box)
        for key, text, fn in (("start_with_windows", "Start Bolo with Windows", self._set_autostart),
                              ("show_bar", "Show the floating bar", self._set_bar)):
            cb = QCheckBox(text)
            cb.setChecked(bool(cfg[key]))
            cb.toggled.connect(fn)
            v.addWidget(cb)
        grid.addWidget(c, 1, 1, Qt.AlignTop)
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 1)
        grid.setRowStretch(2, 1)
        self.bar = None

    def _set_accuracy(self, key):
        self.cfg.set("accuracy", key)
        threading.Thread(target=self.core._preload, daemon=True).start()

    def _set_hotkey(self, key, text):
        text = text.strip().lower()
        if text != self.cfg[key]:
            self.cfg.set(key, text)
            self.on_hotkeys_changed()

    def _set_autostart(self, on):
        self.cfg.set("start_with_windows", bool(on))
        script = str(Path(__file__).resolve().parent.parent / "Bolo.pyw")
        try:
            set_autostart(bool(on), script)
        except Exception:
            pass

    def _set_bar(self, on):
        self.cfg.set("show_bar", bool(on))
        if self.bar is not None:
            self.bar.setVisible(bool(on))


# ---------------------------------------------------------- main window ---
class MainWindow(QWidget):
    def __init__(self, core):
        super().__init__()
        self.core = core
        self.setObjectName("root")
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setWindowTitle("Bolo")
        self.setWindowIcon(make_icon("app"))
        self.resize(1100, 720)
        h = QHBoxLayout(self)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(0)

        side = QFrame()
        side.setObjectName("sidebar")
        side.setFixedWidth(220)
        sv = QVBoxLayout(side)
        sv.setContentsMargins(12, 20, 12, 16)
        sv.setSpacing(4)
        self.pages = QStackedWidget()
        self.dictate = DictatePage(core)
        self.meeting = MeetingPage(core)
        self.settings = SettingsPage(core, self._hotkeys_changed)
        group = QButtonGroup(self)
        self.nav = []
        for i, (name, page) in enumerate((("Dictate", self.dictate), ("Meetings", self.meeting),
                                          ("Settings", self.settings))):
            b = QPushButton(name)
            b.setObjectName("nav")
            b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, n=i: self.pages.setCurrentIndex(n))
            group.addButton(b)
            self.nav.append(b)
            sv.addWidget(b)
            self.pages.addWidget(page)
            if i == 0:
                b.setChecked(True)
        sv.addStretch(1)
        note = _lbl("Everything stays on this PC. Your voice is never uploaded.", "muted", True)
        sv.addWidget(note)
        h.addWidget(side)
        h.addWidget(self.pages, 1)

    def _hotkeys_changed(self):
        self.core.reload_hotkeys()
        self.dictate.refresh_text()
        self.dictate.on_state(self.core.state, "")

    def show_page(self, index):
        self.pages.setCurrentIndex(index)
        self.nav[index].setChecked(True)
        self.show_normal()

    def show_normal(self):
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def closeEvent(self, e):
        e.ignore()
        self.hide()


# ----------------------------------------------------------------- tray ---
def build_tray(app, core, win):
    tray = QSystemTrayIcon(make_icon("app"), app)
    tray.setToolTip("Bolo – click to open")
    menu = QMenu()
    head = QAction("Bolo – ready")
    head.setEnabled(False)
    menu.addAction(head)
    menu.addSeparator()
    lang_menu = menu.addMenu("Language")
    grp = QActionGroup(menu)
    grp.setExclusive(True)
    acts = {}
    for mode in ("en", "hi", "mix"):
        a = QAction(LANG_NAME[mode], lang_menu, checkable=True)
        a.triggered.connect(lambda _=False, m=mode: core.set_language(m))
        grp.addAction(a)
        lang_menu.addAction(a)
        acts[mode] = a

    def sync_lang(mode):
        acts[mode].setChecked(True)
    sync_lang(core.cfg["language_mode"])
    core.language_changed.connect(sync_lang)

    start = menu.addAction("Start / stop dictating")
    start.triggered.connect(core.toggle_dictation)
    rec = menu.addAction("Record meeting")
    rec.triggered.connect(lambda: (win.show_page(1), core.toggle_meeting()))
    menu.addSeparator()
    menu.addAction("Open Bolo").triggered.connect(win.show_normal)
    menu.addAction("Settings").triggered.connect(lambda: win.show_page(2))
    menu.addSeparator()
    quit_act = menu.addAction("Quit Bolo")

    def on_state(state, text):
        head.setText({"idle": "Bolo – ready", "loading": "Bolo – " + (text or "loading"),
                      "listening": "Bolo – listening…", "writing": "Bolo – writing…",
                      "done": "Bolo – ready", "error": "Bolo – " + (text or "problem")}.get(state, "Bolo"))
    core.state_changed.connect(on_state)

    def on_meeting(running, msg):
        rec.setText("Stop meeting recording" if running else "Record meeting")
    core.meeting_changed.connect(on_meeting)

    tray.setContextMenu(menu)
    tray.activated.connect(lambda reason: win.show_normal()
                           if reason in (QSystemTrayIcon.Trigger, QSystemTrayIcon.DoubleClick) else None)
    tray.show()
    return tray, quit_act
