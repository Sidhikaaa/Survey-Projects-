"""Audio capture on Windows (WASAPI).

* kind="mic"      -> your microphone
* kind="loopback" -> everything you hear on this PC (Teams in the browser,
                     the Teams app, Zoom, YouTube ...). No virtual cable needed.

Both deliver 16 kHz mono float32 chunks to a callback, which is what Whisper wants.
"""
import threading

import numpy as np

TARGET_SR = 16000


def _pyaudio():
    import pyaudiowpatch as pyaudio  # Windows only; imported lazily
    return pyaudio


def list_inputs():
    """[(device_index, name)] of real microphones (WASAPI)."""
    try:
        pyaudio = _pyaudio()
        pa = pyaudio.PyAudio()
    except Exception:
        return []
    out = []
    try:
        wasapi = pa.get_host_api_info_by_type(pyaudio.paWASAPI)
        for i in range(pa.get_device_count()):
            d = pa.get_device_info_by_index(i)
            if (d["hostApi"] == wasapi["index"] and d["maxInputChannels"] > 0
                    and not d.get("isLoopbackDevice", False)):
                out.append((i, d["name"]))
    except Exception:
        pass
    finally:
        pa.terminate()
    return out


class AudioSource:
    def __init__(self, kind, device_index, on_audio):
        assert kind in ("mic", "loopback")
        self.kind = kind
        self.device_index = device_index
        self.on_audio = on_audio
        self.level = 0.0
        self.device_name = ""
        self._pa = None
        self._stream = None
        self._rs = None
        self._channels = 1

    # -- device lookup -------------------------------------------------
    def _find_device(self, pyaudio, pa):
        wasapi = pa.get_host_api_info_by_type(pyaudio.paWASAPI)
        if self.kind == "mic":
            if self.device_index is not None:
                return pa.get_device_info_by_index(int(self.device_index))
            return pa.get_device_info_by_index(wasapi["defaultInputDevice"])
        speakers = pa.get_device_info_by_index(wasapi["defaultOutputDevice"])
        if speakers.get("isLoopbackDevice"):
            return speakers
        for loop in pa.get_loopback_device_info_generator():
            if speakers["name"] in loop["name"]:
                return loop
        raise RuntimeError("No loopback device found for your speakers/headphones")

    # -- lifecycle -------------------------------------------------------
    def start(self):
        pyaudio = _pyaudio()
        self._pa = pyaudio.PyAudio()
        try:
            dev = self._find_device(pyaudio, self._pa)
            self.device_name = dev["name"]
            rate = int(dev["defaultSampleRate"])
            self._channels = max(1, int(dev["maxInputChannels"]))
            if rate != TARGET_SR:
                import soxr
                self._rs = soxr.ResampleStream(rate, TARGET_SR, 1, dtype="float32")

            def _cb(in_data, frame_count, time_info, status):
                try:
                    x = np.frombuffer(in_data, dtype=np.float32)
                    if self._channels > 1:
                        x = x.reshape(-1, self._channels).mean(axis=1)
                    if self._rs is not None:
                        x = self._rs.resample_chunk(x)
                    if x.size:
                        self.level = float(np.sqrt(np.mean(x * x)))
                        self.on_audio(x.astype(np.float32, copy=False))
                except Exception:
                    pass
                return (None, pyaudio.paContinue)

            self._stream = self._pa.open(
                format=pyaudio.paFloat32,
                channels=self._channels,
                rate=rate,
                input=True,
                input_device_index=dev["index"],
                frames_per_buffer=int(rate * 0.05),
                stream_callback=_cb,
            )
            self._stream.start_stream()
        except Exception:
            self.stop()
            raise

    def stop(self):
        try:
            if self._stream is not None:
                self._stream.stop_stream()
                self._stream.close()
        except Exception:
            pass
        try:
            if self._pa is not None:
                self._pa.terminate()
        except Exception:
            pass
        self._stream = None
        self._pa = None
        self.level = 0.0


class Recorder:
    """Records the microphone until stop() and returns one float32 array."""

    MAX_SECONDS = 600

    def __init__(self, device_index=None):
        self._chunks = []
        self._len = 0
        self._lock = threading.Lock()
        self.source = AudioSource("mic", device_index, self._on_audio)

    def _on_audio(self, x):
        with self._lock:
            if self._len < self.MAX_SECONDS * TARGET_SR:
                self._chunks.append(x)
                self._len += x.size

    @property
    def level(self):
        return self.source.level

    def start(self):
        self.source.start()

    def stop(self) -> np.ndarray:
        self.source.stop()
        with self._lock:
            audio = np.concatenate(self._chunks) if self._chunks else np.zeros(0, np.float32)
            self._chunks, self._len = [], 0
        return audio
