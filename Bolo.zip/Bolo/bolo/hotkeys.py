"""Global hotkeys (work in every app).

* hold  : press and hold (default Ctrl+Win) -> start, release -> stop
* toggle: press once to start, again to stop (default Ctrl+Alt+Space)
* meeting: start / stop meeting transcript (default Ctrl+Alt+M)
"""
from PySide6.QtCore import QObject, Signal

_ALIASES = {
    "ctrl": {"ctrl", "left ctrl", "right ctrl"},
    "control": {"ctrl", "left ctrl", "right ctrl"},
    "alt": {"alt", "left alt", "right alt", "alt gr"},
    "shift": {"shift", "left shift", "right shift"},
    "windows": {"windows", "left windows", "right windows"},
    "win": {"windows", "left windows", "right windows"},
}


class Hotkeys(QObject):
    hold_start = Signal()
    hold_stop = Signal()
    toggle = Signal()
    meeting = Signal()

    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self._pressed = set()
        self._active = False
        self._groups = []
        self._handles = []
        self._hooked = False
        self._kb = None

    def start(self):
        import keyboard  # needs Windows; imported lazily
        self._kb = keyboard
        self.reload()
        if not self._hooked:
            keyboard.hook(self._on_event)
            self._hooked = True

    def reload(self):
        kb = self._kb
        if kb is None:
            return
        for h in self._handles:
            try:
                kb.remove_hotkey(h)
            except Exception:
                pass
        self._handles = []
        self._groups = []
        for tok in self.cfg["hotkey_hold"].lower().replace(" ", "").split("+"):
            if tok:
                self._groups.append(_ALIASES.get(tok, {tok}))
        for key, sig in (("hotkey_toggle", self.toggle), ("hotkey_meeting", self.meeting)):
            combo = self.cfg[key].strip()
            if combo:
                try:
                    self._handles.append(kb.add_hotkey(combo, sig.emit))
                except Exception:
                    pass

    def _on_event(self, e):
        name = (e.name or "").lower()
        if e.event_type == "down":
            self._pressed.add(name)
        else:
            self._pressed.discard(name)
        if not self._groups:
            return
        now_active = all(any(n in self._pressed for n in g) for g in self._groups)
        if now_active and not self._active:
            self._active = True
            self.hold_start.emit()
        elif not now_active and self._active:
            self._active = False
            self.hold_stop.emit()

    @staticmethod
    def modifiers_down() -> bool:
        try:
            import keyboard
            return any(keyboard.is_pressed(k) for k in ("ctrl", "alt", "shift", "windows"))
        except Exception:
            return False
